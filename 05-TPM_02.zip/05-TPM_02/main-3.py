# variabel adalah wadah yang menumpang nilai / data

# cara menaruh nilai / assignment data 
a =10
x =5
panjang =1000

# memanggil variable
print ("nilaia :",a)
print ("nilai x :",x)
print ("panjang :",panjang)

# penamaan variabel yang benar
nilai_y =15 # menggunakan underscore
juta10 =1000000 # menggunakan angka di depan
nilaiZ =17.5 # variasi angka dan huruf

# assignment indirect
# memberikan nilai variabel dengan nilai
# dari variabel lain

a = 7
print ("nilai a :",a)

b = a
pint ("nilai b :",b)

