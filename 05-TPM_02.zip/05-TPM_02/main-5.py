# input dari user
data = input("masukan data : ")
print("data : " , "tipe : ", type (data))

# jika input adalah angka casting 
angka = float(input("msukkan angka : "))
print("data : ", angka, "tipe : ", type(angka))

