# integer
# tipe data : bilangan bulat tanpa koma
data _integer = 11
print("data = ", data_integer,)
print("- bertipe : ", type(data_integer))

# float
# tipe data : bilangan desimal, dengan koma
data_float = 3.14
print("data = ", data_float)
print("- bertipe : ", type(data_float))

# string
# tipe data : kumpulan karakter
data_string = "Universitas Pendidikan Mandalika"
print("data = ", data_string)
print("- bertipe : ", type(data_string))

# boolean
# tipe data : logika,True/False
data_boolean = True
print("data = ", data_boolean)
print("- bertipe : ", type(data_boolean))
